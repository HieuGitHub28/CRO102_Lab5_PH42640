export const tang=()=>({type: 'TANG'});
export const giam=()=>({type: 'GIAM'});