const initState={
    dem:0,
};
const demReducer=(state=initState,action)=>{
    switch(action.type)
    {
        case 'TANG':
            return {...state,dem: state.dem+1};
        case 'GIAM':
            return {...state,dem: state.dem-1};
        default:
            return state; 
    }
};
export default demReducer;