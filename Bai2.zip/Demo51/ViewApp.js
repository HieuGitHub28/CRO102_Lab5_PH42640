import React from "react";
import { StyleSheet, Text, View, Button, ImageBackground } from "react-native";
import { useSelector, useDispatch } from "react-redux";
import { tang, giam } from "./actions";

const ViewApp = () => {
    const count = useSelector(state => state.dem);
    const dispatch = useDispatch();

    return (
        <ImageBackground
            source={require("./background.jpg")}
            style={styles.backgroundImage}
        >
            <View style={styles.container}>
                <Text style={styles.title}>BÀI 2</Text>
                <Text style={styles.countText}>Đếm: {count}</Text>
                <View style={styles.buttonContainer}>
                    <Button 
                        title="Tăng"
                        onPress={() => dispatch(tang())}
                        color="green"
                    />
                    <View style={styles.buttonSpacer} />
                    <Button
                        title="Giảm"
                        onPress={() => dispatch(giam())}
                        color="green"
                    />
                </View>
            </View>
        </ImageBackground>
    );
}

const styles = StyleSheet.create({
    backgroundImage: {
        width: '100%',
        height: '100%'
    },
    container: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
    },
    title: {
        fontSize: 30,
        fontWeight: 'bold',
        marginBottom: 30,
        color: '#FFFFFF',
        textTransform: 'uppercase',
    },
    countText: {
        fontSize: 28,
        color: '#FFFFFF',
        marginBottom: 25,
    },
    buttonContainer: {
        flexDirection: 'row',
        marginBottom: 20,
    },
    buttonSpacer: {
        width: 20,
    },
});

export default ViewApp;