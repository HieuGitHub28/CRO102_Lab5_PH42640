import React from "react";
import { StyleSheet, Text, View, Button, ImageBackground } from "react-native";
import { useSelector, useDispatch } from "react-redux";
import { tang, giam } from "./store";

const Dem = () => {
    const count = useSelector(state => state.dem);
    const dispatch = useDispatch();

    return (
        <ImageBackground
        source={require("./background1.jpg")}
        style={styles.backgroundImage}
    >
        <View style={styles.container}>
            <Text style={styles.title}>Bài 1</Text>
            <Text style={styles.countText}>Đếm: {count}</Text>
            <View style={styles.buttonContainer}>
                <Button title="Tăng" onPress={() => dispatch(tang())} />
                <View style={styles.buttonSpacer} />
                <Button title="Giảm" onPress={() => dispatch(giam())} />
            </View>
        </View>
        </ImageBackground>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
    },
    title: {
        fontSize: 30,
        fontWeight: 'bold',
        marginBottom: 30,
        color:'white'
    },
    countText: {
        fontSize: 28,
        marginBottom: 25,
        color:'white'
    },
    buttonContainer: {
        flexDirection: 'row',
        marginBottom: 20,
    },
    buttonSpacer: {
        width: 20,
    },
    backgroundImage: {
        width: '100%',
        height: '100%'
    },
});

export default Dem;